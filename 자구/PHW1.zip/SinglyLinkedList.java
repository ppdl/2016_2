/*
 * Name: Cho young jae
 * Student ID:2013147513
 */

public class SinglyLinkedList
{
    /*
     * Our instance variables
     * size will hold the number of elements in the linked list
     * head references the head node in the linked list
     */

    private int size;
    private SinglyLinkedListNode head;

    public SinglyLinkedList()
    {
        /*
         * Our constructor
         * Should initalize the instance variables to their default value
         * Since it is empty at the start, head should be null
         */
    	this.size = 0;
    	this.head = null;
    	
    }

    public SinglyLinkedListNode add(char data, int index)
    {
        /*
         * Adds and returns a new node with the provided data at the specified index
         * Returns null if the index is not possible
         */
    	if(index > size || index < 0) return null;
    	
    	SinglyLinkedListNode newNode = new SinglyLinkedListNode(data);

    	if(index == 0)
    	{
    		newNode.setNext(head);
    		head = newNode;
    		size++;
    		return newNode;
    	}
    	else
    	{
    		newNode.setNext(getNode(index-1).getNext());
    		getNode(index-1).setNext(newNode);
    		size++;
    		return newNode;
    	}
    }

    public SinglyLinkedListNode delete(int index)
    {
        /*
         * Deletes and returns the node at the index specified
         * Returns null if the index does not exist
         */
    	if(index<0 || index>size-1) return null;
    	
    	SinglyLinkedListNode del;
    	if(index==0)
    	{
    		del = head;
    		head = head.getNext();
    		size--;
    		return del;    		
    	}
    	else
    	{
    		del = getNode(index);
    		getNode(index-1).setNext(del.getNext());
    		size--;
    		return del;
    	}
    }

    public SinglyLinkedListNode deleteItem(char data)
    {
        /*
         * Deletes and returns the first node with the specified data in the linked list
         * Returns null if the item doesn't exist
         */
    	for(int i=0; i<size; i++)
    		if(getNode(i).getData()==data)
    		{
    			SinglyLinkedListNode del = getNode(i);
    			delete(i);
    			return del;
    		}
    	return null;
    }

    public boolean contains(char data)
    {
        /*
         * Checks if the linked list contains a node with the specified data
         */
    	for(int i=0; i<size; i++)
    		if(getNode(i).getData()==data)
    		{
    			return true;
    		}
    	return false;
    }

    public int getSize()
    {
        /*
         * Returns the number of elements in the linked list
         */
    	return size;
    }

    public SinglyLinkedListNode getHead()
    {
        /*
         * Returns the head of the linked list
         */
    	return head;
    }

    public int getIndex(char data)
    {
        /*
         * Returns the index of the first node with the specified data
         * Returns -1 if the index does not exist
         */    
    	for(int i=0; i<size; i++)
    		if(getNode(i).getData()==data)
    		{
    			return i;
    		}
    	return -1;
    }

    public SinglyLinkedListNode getNode(int index)
    {
        /*
         * Returns the node at the specified index
         * Returns null if the index does not exist
         */
    	if(index<0 || index>size-1) return null;
    	
    	SinglyLinkedListNode thisNode = head;
    	for(int i=0; i<index; i++)
    		thisNode = thisNode.getNext();
    	return thisNode;
    }

    public boolean isEmpty()
    {
        /*
         * Returns whether or not the linked list is empty
         */
    	if(size==0) return true;
    	else return false;
    }

    public void clear()
    {
        /*
         * Clears the linked list
         */
    	head = null;
    	size = 0;
    }

    public String toString()
    {
        /*
         * Returns the linked list in string form
         * The format is just the data from each node concatenated together
         * See the tests for an example
         * There should be no trailing whitespace
         */
    	String str = new String();
    	SinglyLinkedListNode ptr = head;
    	while(ptr.getNext() != null)
    	{
    		str += ptr.toString();
    		ptr = ptr.getNext();
    	}
    	str += ptr.toString();
    	return str;
    }
}

class SinglyLinkedListNode
{
    /*
     * Our instance variables
     * data will hold a char
     * next is the reference to the next element after this node (null if there is none)
     */

    private char data;
    private SinglyLinkedListNode next;

    public SinglyLinkedListNode(char data)
    {
        /*
         * The constructor
         * Should initalize the instance variables to their default value
         */
    	this.data = data;
    	this.next = null;
    }

    public char getData()
    {
        /*
         * Returns our data
         */
    	return this.data;
    }

    public SinglyLinkedListNode getNext()
    {
        /*
         * Returns the SinglyLinkedListNode referenced by next
         */
    	return this.next;
    }

    public void setData(char data)
    {
        /*
         * Allows us to change the data stored in our SinglyLinkedListNode
         */
    	this.data = data;
    }

    public void setNext(SinglyLinkedListNode node)
    {
        /*
         * Allows us to change the next SinglyLinkedListNode
         */
    	this.next = node;
    }

    public void clearNext()
    {
        /*
         * Removes the reference to the next SinglyLinkedListNode, replacing it with null
         */
    	this.next = null;
    }

    public String toString()
    {
        /*
         * Returns our data in string form
         */
    	return Character.toString(data);
    }
}
