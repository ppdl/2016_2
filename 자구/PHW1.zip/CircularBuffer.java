/*
 * Name:Cho young jae
 * Student ID:2013147513
 */

public class CircularBuffer
{
    /*
     * Our instance variables
     * size will hold the number of elements in the buffer
     * capacity will hold the max number of elements the buffer can have
     * head references the head node in the buffer
     */

    private int size;
    private int capacity;
    private CircularBufferNode head;
    private CircularBufferNode tail;
    private boolean overflow_flag;

    public CircularBuffer(int capacity)
    {
        /*
         * Our constructor
         * Should initalize the instance variables to their default value
         * Since it is empty at the start, head should be null, and overflow_flag should be false
         */
    	size = 0;
    	this.capacity = capacity;
    	head = null;
    	tail = null;
    	overflow_flag = false;
    }

    public CircularBufferNode add(char data)
    {
        /*
         * Adds and returns a new node with the provided data to the end of the buffer
         */
    	CircularBufferNode newNode = new CircularBufferNode(data);	
    	if(!overflow())
    	{
    		if(size == 0)
    		{
    			head = newNode;
    			tail = newNode;
    			tail.setNext(head);
    			size++;
    			return newNode;
    		}
    		else
    		{
    			tail.setNext(newNode);
    			tail = newNode;
    			tail.setNext(head);
    			size++;
    			return newNode;
    		}
    	}
    	else
    	{
    		head = head.getNext();
    		tail.setNext(newNode);
    		tail = newNode;
    		tail.setNext(head);
    		return newNode;
    	}
    	
    }

    public CircularBufferNode delete()
    {
        /*
         * Deletes and returns the node at the front of the buffer
         */
    	CircularBufferNode del = head;
    	head = head.getNext();
    	tail.setNext(head);
    	size--;
    	return del;    	
    }

    public boolean contains(char data)
    {
        /*
         * Checks if the buffer contains a node with the specified data
         */
    	for(int i=0; i<size; i++)
    		if(getNode(i).getData() == data)
    			return true;
    	return false;
    }

    public int getSize()
    {
        /*
         * Returns the number of elements in the buffer
         */
    	return size;
    }

    public int getCapacity()
    {
        /*
         * Returns the capacity of the buffer
         */
    	return capacity;
    }

    public CircularBufferNode getHead()
    {
        /*
         * Returns the head of the buffer
         */
    	return head;
    }

    public CircularBufferNode getTail()
    {
        /*
         * Returns the tail of the buffer
         */
    	return tail;
    }

    public int getIndex(char data)
    {
        /*
         * Returns the index of the first node with the specified data
         * Returns -1 if the index does not exist
         */
    	for(int i=0; i<size; i++)
     		if(getNode(i).getData()==data)
     		{
     			return i;
     		}
     	return -1;        
    }

    public CircularBufferNode getNode(int index)
    {
        /*
         * Returns the node at the specified index
         * Returns null if the index does not exist
         */
    	if(index<0 || index>size-1) return null;
    	
    	CircularBufferNode thisNode = head;
    	for(int i=0; i<index; i++)
    		thisNode = thisNode.getNext();
    	return thisNode;
    }

    public boolean isEmpty()
    {
        /*
         * Returns whether or not the buffer is empty
         */
    	if(size == 0 && head == null && tail == null) return true;
    	else return false;
    }

    public boolean overflow()
    {
        /*
         * Returns whether or not previous operation caused an overflow
         */
    	if(size >= capacity)
    	{
    		overflow_flag = true;
    		return overflow_flag;
    	}
    	else
    	{
    		overflow_flag = false;
    		return overflow_flag;
    	}
    }

    public void clear()
    {
        /*
         * Clears the buffer
         */
    	head = null;
    	tail = null;
    	size = 0;
    	overflow_flag = false;
    }

    public String toString()
    {
        /*
         * Returns the buffer in string form
         * The format is just the data from each node concatenated together
         * See the tests for an example
         * There should be no trailing whitespace
         */
    	String str = new String();
    	CircularBufferNode ptr = head;
    	while(ptr != tail)
    	{
    		str += ptr.toString();
    		ptr = ptr.getNext();
    	}
    	str += ptr.toString();
    	return str;
    }
}

class CircularBufferNode
{
    /*
     * Our instance variables
     * data will hold a char
     * next is the reference to the next element after this node (null if there is none)
     */

    private char data;
    private CircularBufferNode next;

    public CircularBufferNode(char data)
    {
        /*
         * The constructor
         * Should initalize the instance variables to their default value
         */
    	this.data = data;
    }

    public char getData()
    {
        /*
         * Returns our data
         */
    	return data;
    }

    public CircularBufferNode getNext()
    {
        /*
         * Returns the CircularBufferNode referenced by next
         */
    	return next;
    }

    public void setData(char data)
    {
        /*
         * Allows us to change the data stored in our CircularBufferNode
         */
    	this.data = data;
    }

    public void setNext(CircularBufferNode node)
    {
        /*
         * Allows us to change the next CircularBufferNode
         */
    	this.next = node;
    }

    public void clearNext()
    {
        /*
         * Removes the reference to the next CircularBufferNode, replacing it with null
         */
    	this.next = null;
    }

    public String toString()
    {
        /*
         * Returns our data in string form
         */
    	return Character.toString(data);
    }
}
