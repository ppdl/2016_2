/*
 * Name:Cho young jae
 * Student ID:2013147513
 */

public class DoublyLinkedList
{
    /*
     * Our instance variables
     * size will hold the number of elements in the linked list
     * head references the head node in the linked list
     * tail references the tail node in the linked list
     */

    private int size;
    private DoublyLinkedListNode head;
    private DoublyLinkedListNode tail;

    public DoublyLinkedList()
    {
        /*
         * Our constructor
         * Should initalize the instance variables to their default value
         * Since it is empty at the start, head and tail should be null
         */
    	size = 0;
    	head = null;
    	tail = null;
    }

    public DoublyLinkedListNode add(char data, int index)
    {
        /*
         * Adds and returns a new node with the provided data at the specified index
         * Returns null if the index is not possible
         */
    	if(index<0 || index>size) return null;
    	
    	DoublyLinkedListNode newNode = new DoublyLinkedListNode(data);
    	
    	if(index == 0)
    	{
    		newNode.setNext(head);
    		head = newNode;
    		if(newNode.getNext() != null)
    			newNode.getNext().setPrev(newNode);
    		else
    			tail = newNode;
    		size++;
    		return newNode;
    	}
    	else
    	{
    		newNode.setNext(getNode(index-1).getNext());
    		newNode.setPrev(getNode(index-1));
    		getNode(index-1).setNext(newNode);
    		
    		if(newNode.getNext() != null)
    		{
    			newNode.getNext().setPrev(newNode);
    		}
    		else
    			tail = newNode;
    		size++;
    		return newNode;
    	}
    }

    public DoublyLinkedListNode delete(int index)
    {
        /*
         * Deletes and returns the node at the index specified
         * Returns null if the index does not exist
         */
    	if(index<0 || index>size) return null;
    	
    	DoublyLinkedListNode del;
    	if(index == 0)
    	{
    		del = head;
    		if(head != tail) head = head.getNext();
    		else
    		{
    			head = null;
    			tail = null;
    		}
    		size--;
    		return del;
    	}
    	else
    	{
    		del = getNode(index);
    		if(getNode(index) != tail)
    		{
	    		getNode(index-1).setNext(del.getNext());
	    		getNode(index+1).setPrev(del.getPrev());
    		}
    		else
    		{
    			getNode(index-1).setNext(getNode(index).getNext());
    			tail = getNode(index-1);
    		}
    		size--;
    		return del;
    	}
    	
    }

    public DoublyLinkedListNode deleteItem(char data)
    {
        /*
         * Deletes and returns the first node with the specified data in the linked list
         * Returns null if the item doesn't exist
         */
    	for(int i=0; i<size; i++)
    		if(getNode(i).getData()==data)
    		{
    			DoublyLinkedListNode del = getNode(i);
    			delete(i);
    			return del;
    		}
    	return null;
    }

    public boolean contains(char data)
    {
        /*
         * Checks if the linked list contains a node with the specified data
         */
    	for(int i=0; i<size; i++)
     		if(getNode(i).getData()==data)
     		{
     			return true;
     		}
     	return false;
    }

    public int getSize()
    {
        /*
         * Returns the number of elements in the linked list
         */
    	return size;
    }

    public DoublyLinkedListNode getHead()
    {
        /*
         * Returns the head of the linked list
         */
    	return head;
    }

    public DoublyLinkedListNode getTail()
    {
        /*
         * Returns the tail of the linked list
         */  
    	return tail;
    }

    public int getIndex(char data)
    {
        /*
         * Returns the index of the first node with the specified data
         * Returns -1 if the index does not exist
         */
    	for(int i=0; i<size; i++)
     		if(getNode(i).getData()==data)
     		{
     			return i;
     		}
     	return -1;       
    }

    public DoublyLinkedListNode getNode(int index)
    {
        /*
         * Returns the node at the specified index
         * Returns null if the index does not exist
         */
    	if(index<0 || index>size-1) return null;
    	
    	DoublyLinkedListNode thisNode = head;
    	for(int i=0; i<index; i++)
    		thisNode = thisNode.getNext();
    	return thisNode;
    }

    public boolean isEmpty()
    {
        /*
         * Returns whether or not the linked list is empty
         */
    	if(size==0) return true;
    	else return false;
    }

    public void clear()
    {
        /*
         * Clears the linked list
         */
    	head = null;
    	tail = null;
    	size = 0;
    }

    public String toString()
    {
        /*
         * Returns the linked list in string form
         * The format is just the data from each node concatenated together
         * See the tests for an example
         * There should be no trailing whitespace
         */
    	String str = new String();
    	DoublyLinkedListNode ptr = head;
    	while(ptr != tail)
    	{
    		str += ptr.toString();
    		ptr = ptr.getNext();
    	}
    	str += ptr.toString();
    	return str;
    }

    public String toStringReverse()
    {
        /*
         * Returns the linked list in string form in reverse
         * The format is just the data from each node concatenated together
         * There should be no trailing whitespace
         * Do not just call toString and reverse it, this will receive no points
         */
    	String str = new String();
    	DoublyLinkedListNode ptr = tail;
    	while(ptr != head)
    	{
    		str += ptr.toString();
    		ptr = ptr.getPrev();
    	}
    	str += ptr.toString();
    	return str;
    }
}

class DoublyLinkedListNode
{
    /*
     * Our instance variables
     * data will hold a char
     * next is the reference to the next element after this node (null if there is none)
     */

    private char data;
    private DoublyLinkedListNode next;
    private DoublyLinkedListNode prev;

    public DoublyLinkedListNode(char data)
    {
        /*
         * The constructor
         * Should initalize the instance variables to their default value
         */
    	this.data = data;
    	this.next = null;
    	this.prev = null;
    }

    public char getData()
    {
        /*
         * Returns our data
         */
    	return data;
    }

    public DoublyLinkedListNode getNext()
    {
        /*
         * Returns the DoublyLinkedListNode referenced by next
         */
    	return next;
    }

    public DoublyLinkedListNode getPrev()
    {
        /*
         * Returns the DoublyLinkedListNode referenced by prev
         */        
    	return prev;
    }

    public void setData(char data)
    {
        /*
         * Allows us to change the data stored in our DoublyLinkedListNode
         */
    	this.data = data;
    }

    public void setNext(DoublyLinkedListNode node)
    {
        /*
         * Allows us to change the next DoublyLinkedListNode
         */
    	this.next = node;
    }

    public void setPrev(DoublyLinkedListNode node)
    {
        /*
         * Allows us to change the prev DoublyLinkedListNode
         */
    	this.prev = node;
    }

    public void clearNext()
    {
        /*
         * Removes the reference to the next DoublyLinkedListNode, replacing it with null
         */
    	this.next = null;
    }

    public void clearPrev()
    {
        /*
         * Removes the reference to the prev DoublyLinkedListNode, replacing it with null
         */
    	this.prev = null;
    }

    public String toString()
    {
        /*
         * Returns our data in string form
         */
    	return Character.toString(data);
    }
}
